// inicializamos con la función de flexslider()
jQuery(document).ready(function($) {
  $('.flexslider').flexslider({
    animation: "slide"
  });
});